package a4;

import androidx.datastore.preferences.core.MutablePreferences;
import androidx.datastore.preferences.core.Preferences;
import kotlin.ResultKt;
import kotlin.Unit;
import kotlin.coroutines.Continuation;
import kotlin.coroutines.jvm.internal.SuspendLambda;
import kotlin.jvm.functions.Function2;
import qd.a;

public final class d extends SuspendLambda implements Function2 {
    public int o;
    public Object p;
    public final Function2 q;

    public d(Function2 function20, Continuation continuation0) {
        this.q = function20;
        super(2, continuation0);
    }

    @Override  // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Continuation create(Object object0, Continuation continuation0) {
        Continuation continuation1 = new d(this.q, continuation0);
        continuation1.p = object0;
        return continuation1;
    }

    @Override  // kotlin.jvm.functions.Function2
    public final Object invoke(Object object0, Object object1) {
        return ((d)this.create(((Preferences)object0), ((Continuation)object1))).invokeSuspend(Unit.INSTANCE);
    }

    @Override  // kotlin.coroutines.jvm.internal.BaseContinuationImpl
    public final Object invokeSuspend(Object object0) {
        Object object1 = a.getCOROUTINE_SUSPENDED();
        switch(this.o) {
            case 0: {
                ResultKt.throwOnFailure(object0);
                MutablePreferences mutablePreferences0 = ((Preferences)this.p).toMutablePreferences();
                this.p = mutablePreferences0;
                this.o = 1;
                return this.q.invoke(mutablePreferences0, this) == object1 ? object1 : mutablePreferences0;
            }
            case 1: {
                MutablePreferences mutablePreferences1 = (MutablePreferences)this.p;
                ResultKt.throwOnFailure(object0);
                return mutablePreferences1;
            }
            default: {
                throw new IllegalStateException("call to \'resume\' before \'invoke\' with coroutine");
            }
        }
    }
}

