package android.webkit;

public class WebViewRenderProcessClient {
    static {
        throw new NoClassDefFoundError();
    }
}

