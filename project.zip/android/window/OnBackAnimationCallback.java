package android.window;

public interface OnBackAnimationCallback extends OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

