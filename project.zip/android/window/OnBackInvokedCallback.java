package android.window;

public interface OnBackInvokedCallback {
    static {
        throw new NoClassDefFoundError();
    }
}

