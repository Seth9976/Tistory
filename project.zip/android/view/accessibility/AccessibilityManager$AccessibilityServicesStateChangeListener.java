package android.view.accessibility;

public interface AccessibilityManager.AccessibilityServicesStateChangeListener {
    static {
        throw new NoClassDefFoundError();
    }
}

