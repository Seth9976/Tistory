package android.view;

public interface OnReceiveContentListener {
    static {
        throw new NoClassDefFoundError();
    }
}

