package android.view.inspector;

public interface InspectionCompanion {
    static {
        throw new NoClassDefFoundError();
    }
}

