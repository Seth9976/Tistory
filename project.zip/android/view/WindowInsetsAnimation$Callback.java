package android.view;

public class WindowInsetsAnimation.Callback {
    static {
        throw new NoClassDefFoundError();
    }
}

