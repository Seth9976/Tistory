package android.graphics;

public interface ImageDecoder.OnHeaderDecodedListener {
    static {
        throw new NoClassDefFoundError();
    }
}

