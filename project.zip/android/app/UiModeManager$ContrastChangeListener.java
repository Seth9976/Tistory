package android.app;

public interface UiModeManager.ContrastChangeListener {
    static {
        throw new NoClassDefFoundError();
    }
}

