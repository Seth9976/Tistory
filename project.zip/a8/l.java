package a8;

import com.google.android.material.progressindicator.IndeterminateDrawable;

public abstract class l {
    public IndeterminateDrawable a;
    public final float[] b;
    public final int[] c;

    public l(int v) {
        this.b = new float[v * 2];
        this.c = new int[v];
    }

    public abstract void a();

    public abstract void b();

    public abstract void c(b arg1);

    public abstract void d();

    public abstract void e();

    public abstract void f();
}

