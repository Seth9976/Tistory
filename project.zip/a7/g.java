package a7;

public abstract class g {
    public static final e[] a;

    static {
        g.a = new e[]{h.c, h.d};
    }
}

