package androidx.appcompat.app;

import androidx.annotation.DoNotInline;

public abstract class l0 {
    @DoNotInline
    public static int a() [...] // Inlined contents
}

