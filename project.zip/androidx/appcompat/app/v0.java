package androidx.appcompat.app;

public final class v0 {
    public boolean a;
    public long b;

}

