package androidx.appcompat.view.menu;

import androidx.appcompat.widget.MenuPopupWindow;

public final class g {
    public final MenuPopupWindow a;
    public final MenuBuilder b;
    public final int c;

    public g(MenuPopupWindow menuPopupWindow0, MenuBuilder menuBuilder0, int v) {
        this.a = menuPopupWindow0;
        this.b = menuBuilder0;
        this.c = v;
    }
}

