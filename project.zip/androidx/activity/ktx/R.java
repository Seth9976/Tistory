package androidx.activity.ktx;

public final class R {
}

