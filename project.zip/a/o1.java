package a;

import b.s;

public abstract class o1 {
    public static final int[] a;

    static {
        int[] arr_v = new int[s.values().length];
        try {
            arr_v[s.d.ordinal()] = 1;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.e.ordinal()] = 2;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.f.ordinal()] = 3;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.g.ordinal()] = 4;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.h.ordinal()] = 5;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.i.ordinal()] = 6;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.j.ordinal()] = 7;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.k.ordinal()] = 8;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        try {
            arr_v[s.l.ordinal()] = 9;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        o1.a = arr_v;
    }
}

