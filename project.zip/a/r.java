package a;

import b.s;

public abstract class r {
    public static final int[] a;

    static {
        int[] arr_v = new int[s.values().length];
        try {
            arr_v[s.j.ordinal()] = 1;
        }
        catch(NoSuchFieldError unused_ex) {
        }
        r.a = arr_v;
    }
}

