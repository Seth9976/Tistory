package aa;

import androidx.compose.runtime.MutableState;
import com.kakao.kandinsky.decoration.DecorationBoxKt;
import kotlin.Unit;
import kotlin.jvm.functions.Function0;
import kotlin.jvm.internal.Lambda;

public final class n extends Lambda implements Function0 {
    public final MutableState w;

    public n(MutableState mutableState0) {
        this.w = mutableState0;
        super(0);
    }

    @Override  // kotlin.jvm.functions.Function0
    public final Object invoke() {
        DecorationBoxKt.access$BasicDecorationBox_vzil_yM$lambda$5(this.w, 0L);
        return Unit.INSTANCE;
    }
}

