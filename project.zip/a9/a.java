package a9;

import g.b;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

public final class a extends b {
    @Override  // g.b
    public final Method k(Class class0, Field field0) {
        throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
    }

    @Override  // g.b
    public final Constructor l(Class class0) {
        throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
    }

    @Override  // g.b
    public final String[] p(Class class0) {
        throw new UnsupportedOperationException("Records are not supported on this JVM, this method should not be called");
    }

    @Override  // g.b
    public final boolean s(Class class0) {
        return false;
    }
}

