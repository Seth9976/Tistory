import androidx.compose.runtime.Composer;
import androidx.compose.runtime.CompositionLocalMap;
import androidx.compose.ui.layout.MeasurePolicy;
import androidx.compose.ui.node.ComposeUiNode.Companion;
import kotlin.jvm.functions.Function2;

public abstract class a {
    public static Function2 a(Companion composeUiNode$Companion0, Composer composer0, MeasurePolicy measurePolicy0, Composer composer1, CompositionLocalMap compositionLocalMap0) {
        return androidx.room.a.r(composeUiNode$Companion0, composer0, measurePolicy0, composer1, compositionLocalMap0);
    }
}

